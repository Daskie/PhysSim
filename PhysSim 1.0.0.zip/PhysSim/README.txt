Requirements:
- Java 6 or higher
- OpenGL 4.1 or higher

PhysSim is a 3D visualization tool for electric field and potential created by any number of charged objects in any arbitrary location and orientation in space.

This was created as a project for the physics class PHYS 133-50 of Spring 2016 at California Polytechnic State University San Luis Obispo. It was completed under very tight time constraints, so corners had to be cut and certain features left out. I do not claim this program to be at all bug free, robust, or polished. I do consider it a functional prototype. Given time and the incentive, I can flesh this project out into a fully functional program.

Project Report:
https://docs.google.com/document/d/1PYnERf62TFtaPqi0zvoRcg6mRlYaXlDGl9m8MQLOzM4

Created by Austin D. Quick